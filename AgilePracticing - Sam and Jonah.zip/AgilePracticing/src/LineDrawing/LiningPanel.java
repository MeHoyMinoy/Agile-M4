package LineDrawing;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

public class LiningPanel extends javax.swing.JPanel {

    public LiningPanel() { }
    Random r = new Random();        //allows colors to change randomly
        int red = r.nextInt(256);   //chooses a random int to represent a color
        int green = r.nextInt(256);
        int blue = r.nextInt(256);
        
        Color c = new Color(red,green,blue);    //assigns the random color
        
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        int w = getWidth();
        int h = getHeight();


        g.setColor(c);                      //sets the color
        

        double lines = 15.0;

        for(int i = 0; i < lines; i++)
        {
            int w2 = (int)((i/lines)*w); 
            int h2 = (int)((i/lines)*h); 
            int w3 = w-w2; 
            int h3 = h-h2;
            
            g.drawLine(0,  h2, w2, h);  //bottom left
            g.drawLine(w,  h2, w2, 0);  //top right
            
            g.drawLine(w,  h2, w3, h);  //bottom right
            g.drawLine(0,  h3, w2, 0);  //top left
        }
        
    }
    
}
