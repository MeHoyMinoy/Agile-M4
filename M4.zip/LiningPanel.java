
import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;


public class LiningPanel extends javax.swing.JPanel {

    public LiningPanel() { }

    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        int w = getWidth();
        int h = getHeight();
        
        Random ran = new Random();      //random obj for random nums
        //rgb values for myColor
        int r = ran.nextInt(255)+1;
        int gr = ran.nextInt(255)+1;
        int b = ran.nextInt(255)+1;
        //number lines and defined color
        
        double lines = 15.0;
        Color myColor;
        
        for(int i = 0; i < lines; i++)
        {
            //gets new rgb color numbers 
            r = ran.nextInt(255)+1;
             gr = ran.nextInt(255)+1;
             b = ran.nextInt(255)+1;
             //sets color to random color
             myColor = new Color(r,gr,b);
             
            int w2 = (int)((i/lines)*w); 
            int h2 = (int)((i/lines)*h); 
            
            //sets color to the lines
            g.setColor(myColor);
        
            
            //draws lines to panel
            g.drawLine(0,  h-h2, w2, 0);
            g.drawLine(w2,  0, w, h2);
            g.drawLine(w,  h2, w-w2, h);
            g.drawLine(0,  h2, w2, h);
        }
        
    }
    
}
